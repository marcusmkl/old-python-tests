"""
Laboratory Exercise #8
POLYMORPHISM
"""

from abc import ABC, abstractmethod

class PaymentMethod(ABC):

    @abstractmethod
    def validate(self):
        pass

    @abstractmethod
    def process_payment(self, amount: float):
        pass

class CreditCardPayment(PaymentMethod):

    def validate(self):
        card_num = input("Input Credit Card Number: ")
        if len(card_num) == 16:
            return True
        else:
            print("Invalid Credit Card")
            return False

    def process_payment(self, amount: float):
        print(f"Processing credit card payment of $: {amount}")

class PayPalPayment(PaymentMethod):

    def validate(self):
        email = "user@gmail.com"
        password = "123456789"

        val_email = input("Input Email Address: ")
        val_password = input("Input Password: ")

        if val_email == email and val_password == password:
            return True
        else:
            print("Username or password is invalid")
            return False

    def process_payment(self, amount: float):
        print(f"Processing paypal payment of $: {amount}")

class CryptoPayment(PaymentMethod):

    def validate(self):
        wallet_id = input("Enter Wallet ID: ")
        if wallet_id:
            print("Wallet validated")
            return True
        else:
            print("Invalid Wallet ID")
            return False


    def process_payment(self, amount: float):
        print(f"Amount: {amount}")


def checkout(payment: PaymentMethod, amount: float):
    value = payment.validate()

    if value:
        payment.process_payment(amount)


checkout(CreditCardPayment(), 1000)
checkout(PayPalPayment(), 1000)
checkout(CryptoPayment(), 1000)